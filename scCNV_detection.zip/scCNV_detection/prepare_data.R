#set working directory
setwd("C:/Users/Daniel/Desktop/scCNV") #

#load reference hepatocyte data
hep_data<-read.delim(file="hepatocyte_filtered_sorted_transposed_saturated.txt",sep="\t",header=TRUE,row.names=1)

sink("hepatocyte_reference.txt")
for (g in 1:(ncol(hep_data)-99)){
#first extract expression values from 100 genes and then calculate mean and SD
g2<-g+99

rowmean<-rowMeans(as.matrix(hep_data[,g:g2]))
cat (g,"\t",mean(rowmean),"\t",sd(rowmean),"\n",sep="")
g<-g+1
}
sink()


#load experimental data
HCC_data<-read.delim(file="8cases_tumor_cells_filtered_sorted_transposed_saturated.txt",sep="\t",header=TRUE,row.names=1)

sink("HCC_data.txt")
for (g in 1:(ncol(HCC_data)-99)){
#first extract expression values from 100 genes and then calculate mean and SD
g2<-g+99

rowmean<-rowMeans(as.matrix(HCC_data[,g:g2]))
cat (g,rowmean,"\n")
g<-g+1
}
sink()


#transpose experimental data
temp<-read.table(file="HCC_data.txt")
write.table(t(temp),file="HCC_data_transposed.txt",sep="\t",quote=FALSE,row.names=FALSE,col.names=FALSE)


#export cell ID
write.table((rownames(HCC_data)),file="cell_ID.txt",quote=FALSE,row.names=FALSE,col.names=FALSE)		#cell ID
