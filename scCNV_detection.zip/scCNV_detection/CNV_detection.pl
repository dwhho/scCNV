#usage: perl CNV_detection.pl reference.txt cell_ID.txt data.txt output fold

#command-line arguments extraction
my $reference = $ARGV[0];
my $cell_ID = $ARGV[1];
my $data = $ARGV[2];
my $output = $ARGV[3];
my $output_CNV = $output . "_CNV.txt";
my $output_plot = $output . "_plot.txt";
my $fold = $ARGV[4];

#open output file
open(OUTPUT_CNV, ">$output_CNV");			#file for CNV (-1, 0 1)
open(OUTPUT_PLOT, ">$output_plot");			#file for CNV value

my %ref_mean;
my %ref_sd;
my @cell_ID = ();
my $first_line = 1;
my $count = "";

########################
#read in reference file#
########################
open(REF, $reference);
while (my $line = <REF>) {
	chomp($line);

	my @column = split("\t",$line);

	$ref_mean{$column[0]}=$column[1];
	$ref_sd{$column[0]}=$column[2];
}

#################
#read in cell ID#
#################
open(CELL, $cell_ID);
while (my $line = <CELL>) {
	chomp($line);

	push @cell_ID, $line;
}

###################
#read in data file#
###################
open(DATA, $data);
while (my $line = <DATA>){
	chomp($line);

	if ($first_line) {
		print OUTPUT_CNV "$line\n";
		print OUTPUT_PLOT "$line\n";

		$first_line = 0;
		$count = 0;
	}
	else {
		my @column = split("\t",$line);

		print OUTPUT_CNV "$cell_ID[$count]";
		print OUTPUT_PLOT "$cell_ID[$count]";

		for (my $i=0; $i < scalar @column; $i++) {
			my $exp = $column[$i];
			my $hep_mean = $ref_mean{$i+1};
			my $hep_sd = $ref_sd{$i+1};

			if ($exp > $hep_mean+($fold*$hep_sd)) {			#CNV of certain fold of SD above reference mean
				print OUTPUT_CNV "\t1";
				print OUTPUT_PLOT "\t$exp";
			}
			elsif ($exp < $hep_mean-($fold*$hep_sd)){		#CNV of certain fold of SD below reference mean
				print OUTPUT_CNV "\t-1";
				print OUTPUT_PLOT "\t$exp";
			}
			else {											#no CNV
				print OUTPUT_CNV "\t0";
				print OUTPUT_PLOT "\t0";
			}
		}
		
		print OUTPUT_CNV "\n";
		print OUTPUT_PLOT "\n";

		$count++;
	}
}
close INPUT;